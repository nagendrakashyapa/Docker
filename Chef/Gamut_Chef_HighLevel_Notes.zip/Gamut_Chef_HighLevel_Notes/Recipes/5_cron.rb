# This recipe reboots all servers. this is required to remove some zombie proceses
cron 'reboot server' do
   command 'reboot'
   hour '6'
   minute '00'
   user "gamut"
 end


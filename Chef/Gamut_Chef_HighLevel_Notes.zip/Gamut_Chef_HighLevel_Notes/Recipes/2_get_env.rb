file "#{ENV['HOME']}/deployment_info.txt" do
  content "Login User name: #{ENV['USER']}\nJava is installed at: #{ENV['JAVA_HOME']}\n"
end


user 'harry' do
  comment 'Created by Chef for testing teams'
  manage_home true
  home '/home/harry'
  shell '/bin/bash'
  password 'harry123'
end


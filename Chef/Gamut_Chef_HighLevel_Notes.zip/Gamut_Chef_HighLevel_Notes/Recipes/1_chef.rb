file 'deployment.txt' do
  content 'deployment is succussful'
  mode '755'
  user 'web'
  group 'web'	
end

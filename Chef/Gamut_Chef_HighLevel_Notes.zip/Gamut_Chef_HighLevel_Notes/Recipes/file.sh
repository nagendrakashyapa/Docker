#!/bin/bash
#
for i in bacon sasuage eggs
do
	echo "$i is delicious!" > $i.txt
done


file 'reboot.log' do
  content "machine reboots!\n"
  action :delete
end


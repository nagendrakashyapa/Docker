['bacon', 'eggs', 'sasuage'].each do |filename|
  file "#{filename}" do
    content "#{filename} is delicious!\n"
  end
end


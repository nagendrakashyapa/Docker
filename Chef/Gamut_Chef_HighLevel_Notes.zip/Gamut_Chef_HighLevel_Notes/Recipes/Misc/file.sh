#!/bin/bash

for i in bacon eggs sasuage
do
	echo "$i is delicious!" > $i.txt
done

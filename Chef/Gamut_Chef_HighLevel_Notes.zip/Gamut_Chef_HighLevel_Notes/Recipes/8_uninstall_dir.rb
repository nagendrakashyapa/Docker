directory 'deployments' do
  recursive true
  action :delete
end

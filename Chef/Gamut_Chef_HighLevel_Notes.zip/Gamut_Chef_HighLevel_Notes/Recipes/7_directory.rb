directory 'build' do
  recursive true
  action :delete
end

